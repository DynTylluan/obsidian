obsidian 11.07b alpha release

This is a small readme for the purpose of informing people on what to (not) expect from this obsidian release.

 - Coop mode doesn't work at all. Don't even try it, always use -deathmatch or similar.
 - -altdeath and -newdeath likely do not work at all, yet.
 - Sector data upon connect is going to be a bit out of date. This shouldn't be too noticable.
 - There is a max player name length of 10 characters, I haven't increased this yet.
 - I am using Doom's message code still, there's a limit of 80 characters/1-line showing at a time.
   - (Due to this, I strongly recommend running obsidian from the command prompt so you can see messages better)
 - There is a limit of 4 players, just like in vanilla. Work is in progress for 16 player support.
 - There is no scoreboard, except for on the exit screen, just like in vanilla.
 - There is no way to disable the exit yet.
 - Exiting on MAP30 will probably mess up very badly.
 - Firing is not delayed clientside, this will lead to worse and worse visual oddities as ping goes up.
 - Probably more, tell me please: https://bitbucket.org/tm512/obsidian/issues/

To run a server, use the -server parameter, for example:

  obsidian.exe -server -file exec.wad -deathmatch

You may also specify a port other than the default (11666) by using the -port parameter.

To connect a client, simply use -connect, along with -file to load whatever wads the server has loaded, for example:

  obsidian.exe -connect altdeath.com:10676 -file exec.wad

Web: https://bitbucket.org/tm512/obsidian/
IRC: irc://irc.oftc.net/obsidian/
Email: tetrismaster512@hotmail.com
